#!/usr/bin/python3
# coding: utf-8
# įvykdyti:
# ./z.py
# arba
# python3 z.py
# arba įvykdyti iš python3 shell:
# exec(open('z.py').read())

import math
import numpy as np
#import matplotlib.pyplot as plt
#from mpl_toolkits import mplot3d
import imageio as iio
import skimage                 # skimage library
from skimage.color import rgb2gray
#from scipy import ndimage

img0 = iio.imread('IMAGE.png')
imgG = rgb2gray(img0)  # pilkas

R_o = 100; R_i = 20
N_sectors =  256 #180               # 360 laipsnių apskritimo lankas suskirstomas į "N_sectors" sektorių
phi_h = 2*math.pi /N_sectors  # sektoriaus kampas, minimalus kampo žingsnis
# kampo tinklelis:
angular_phi = []              # kampo "phi" vertės radianais
angular_phiDeg = []           # kampo "phi" vertės laipsniais
for i_sector in range(0, N_sectors):
    angular_phi.append(i_sector * phi_h)
    angular_phiDeg.append(i_sector * 360 /N_sectors )

# funkcija "adjust_0" paverčia labai mažą skaičių tiksliu nuliu
def adjust_0(skaiciukas):  
    if math.fabs(skaiciukas) <= 1e-14:
        skaiciukas = 0.0
    return skaiciukas

# Funkcija "SectorDimensions" nustato sektoriaus (kurio indeksas "i_sector") parametrus.
# Iš to sektoriaus bus pasirenkami pikseliai, esantys tarp apskritimų "R_i" ir "R_o",
# ir tarp kampų "phi_a" ir "phi_b"
def SectorDimensions(i_sector):
    global phi_h, R_i, R_o 
    phi_a = i_sector * phi_h - math.pi  # kampas matuojamas nuo -pi iki pi (pagal math.atan2).
    phi_a = phi_a + 0.01 * math.pi      # suvienodina tinklelį ties 45, 135, 225 ir 315 laipsniais
    phi_b = phi_a + phi_h
    sinA = math.sin(phi_a);   cosA = math.cos(phi_a)
    sinB = math.sin(phi_b);   cosB = math.cos(phi_b)
    # Kampui esant 0, pi arba +/- pi/2 gautos Sin arba Cos skaitmeninės
    # vertės gali būti ne tikslūs nuliai, bet apie < 1e-15. Tai trukdo
    # tolimesniam algoritmui. Funkcija "adjust_0" tokias vertes 
    # pakeičia tiksliu nuliu.
    sinA = adjust_0(sinA);    cosA = adjust_0(cosA)
    sinB = adjust_0(sinB);    cosB = adjust_0(cosB)
    # pixelių koordinatės "(x, y)" bus ieškomos 
    # intervaluose "x_min <= x <= x_max" ir "y_min <= y <= y_max"
    x_min = math.floor( min( [ R_i * cosA, R_i * cosB, R_o * cosA, R_o * cosB ] ) )
    x_max = math.ceil(  max( [ R_i * cosA, R_i * cosB, R_o * cosA, R_o * cosB ] ) )
    y_min = math.floor( min( [ R_i * sinA, R_i * sinB, R_o * sinA, R_o * sinB ] ) )
    y_max = math.ceil(  max( [ R_i * sinA, R_i * sinB, R_o * sinA, R_o * sinB ] ) )
    return phi_a, phi_b, x_min, x_max, y_min, y_max

# Atrenkamos pikselių koordinatės
mesh_phi = []        # atrinktų pikselių koordinačių sąrašas
mesh_phiW = []
for i_sector in range(0, N_sectors):
    phi_a, phi_b, x_min, x_max, y_min, y_max = SectorDimensions(i_sector)
    mesh_r = []      # pikselių, patenkančių į "i_sector" sektorių, koordinačių sąrašas
    n_weight = 0     # skaičiuoja pikselių kiekį sektoriuje
    for ix in range(x_min, x_max + 1):
        x = ix + 0.5
        x2 = x**2
        for iy in range(y_min, y_max + 1):
            y = iy + 0.5
            rho = math.sqrt(x2 + y**2)
            if (rho >= R_i) and ( rho <= R_o):  # tikrina ilgį
                phi = math.atan2(y, x)
                if (i_sector == N_sectors-1) & (phi <= 0.0):
                    phi = 2*math.pi + phi
                if (phi >= phi_a) and (phi < phi_b):
                    n_weight = n_weight + 1
                    mesh_r.append([ix, iy])
    mesh_phi.append(mesh_r)
    mesh_phiW.append(n_weight)

# Ieškoma kampinė funkcija aplink centrinį pikselį.
# (ix0, iy0) # centrinis pixelis
ix0, iy0 = 180, 320
angular_f = []       # f(phi) funkcijos vertės
for i_sector in range(0, N_sectors):
    mesh_r = mesh_phi[i_sector]
    af = 0.0
    for i in range(0, len(mesh_r)):
        ix, iy =  mesh_r[i][0], mesh_r[i][1]
        ix = ix + ix0
        iy = iy + iy0
        af = af + imgG[ix, iy]
    af = af / mesh_phiW[i_sector]
    angular_f.append(af)

# normavimas, nulių skaičiavimas
fzero = np.mean(angular_f)
tempList = angular_f - fzero
countZero = 0
fnorm = 0.0
signA = tempList[0]
for i_sector in range(0, N_sectors):
    signB = tempList[i_sector]
    fnorm = fnorm + tempList[i_sector]**2
    if signB*signA < 0.0:
        countZero = countZero + 1
        signA = signB
    
fnorm = math.sqrt(fnorm /N_sectors)
# normuota funkcija "fn(phi)"
angular_fn = tempList/fnorm

powerMax = int( math.log2(countZero/2) )
#print(countZero, powerMax)

#plt.plot(angular_phiDeg, angular_fn)
#plt.show()

def findCovariance(discreteFunction, N, shift):
    cov = 0
    for i in range(0, N):
        j = (i + shift) % N  # mod(i+shift, N)
        cov = cov + discreteFunction[i] * discreteFunction[j]
    cov = cov /N
    return cov

correlator = [0.0]*6
for i in range(0,powerMax):
    power = i+1
    order = 2**power
    Period = int(N_sectors /order)
    corr = findCovariance(angular_fn, N_sectors, Period)
    correlator[i] = corr
#    print(corr, i, power, order) #, Period)

#for i in range(0,6):
#    print(correlator[i])

#print(', '.join('{:0.6f}'.format(i) for i in correlator))
ff = open("python.dat", "w")
ff.write(', '.join('{:0.6f}'.format(i) for i in correlator))
ff.close()

#viskas

